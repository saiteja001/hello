export class User {
     tid!:number;
     firstname!:string ;
     lastname!:string;
     age!:number;
     gender!:string;
     fplace!:string;
     nodv!:number;
}
